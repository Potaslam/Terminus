#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo 'Instala Node.js LTS desde https://nodejs.org/'
  exit 1
fi
printf 'Abre http://localhost:3007 en tu navegador.\n'
node server.js
