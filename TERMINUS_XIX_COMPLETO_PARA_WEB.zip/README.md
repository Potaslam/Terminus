# TERMINUS XIX — Boss Rush: versión web lista para publicar

**Tres jefes:** Regente de Ceniza, The Celestial y Catalyst.

Esta versión repara las rutas de **los dos sprites GIF y los tres MP3** y
permite jugar **solo sin servidor**, en la red local, o en **una página pública
permanente con WebSockets**. Los controles, fases y estadísticas de combate
se conservaron desde TERMINUS XVIII.

## 🎮 Jugar solo ahora mismo (Windows)

Extrae todo el ZIP y haz doble clic en `JUGAR_SOLO.bat`. No necesitas instalar
Node.js. El navegador debe abrir `index.html` dentro de la carpeta extraída.
Pulsa INICIAR COMBATE para que el navegador permita iniciar la canción.
Comprueba que arriba diga `MÚSICA: ON` y que el volumen no sea cero.

## 🌐 Publicar URL permanente para tus amigos

Necesitas una cuenta gratuita de GitHub y otra de Render; **esta descarga por
sí sola NO crea una URL pública**. En Render, **Free** funciona con WebSockets.

1. Ve a <https://github.com/new> y crea un repositorio nuevo, por ejemplo
   `terminus-boss-rush` (puede ser privado si luego conectas ese repositorio
   en Render).
2. Abre el repositorio en GitHub → `Add file` → `Upload files`.
3. Arrastra el **contenido de esta carpeta** (no el ZIP): `server.js`,
   `index.html`, `package.json`, `render.yaml`, y las carpetas `audio/` y
   `assets/`. Asegúrate de que `server.js` esté en la raíz.
4. Haz clic en `Commit changes` y espera a que los MP3 se terminen de subir.
5. En <https://dashboard.render.com/> elige `New` → `Web Service`.
6. Conecta GitHub, escoge el repositorio que acabas de crear y configúralo:

   - **Runtime**: Node
   - **Instance type**: Free
   - **Build Command**: `npm install --omit=dev`
   - **Start Command**: `npm start`
   - **Health Check Path**: `/healthz`

7. Pulsa `Deploy Web Service` y espera a que el estado aparezca como **Live**.
8. Render te enseñará **TU** URL `https://...onrender.com`. Esa dirección es
   la que compartirás. El nombre exacto dependerá de qué nombre esté libre.
9. Tú y tus dos amigos abrirán **la misma URL**, seleccionarán MULTIJUGADOR,
   crearán una sala y entrarán con su código de seis caracteres.

**Sin Cloudflare, sin localhost.run, sin abrir puertos, sin dejar la PC prendida.**

> Render Free detiene servicios tras unos 15 minutos sin actividad y el
> siguiente visitante puede esperar alrededor de un minuto. La URL no cambia.
> Si Render reinicia el proceso durante una pelea, se pierden las salas activas:
> las salas son temporales y viven en la memoria del servidor.

## 🔧 Prueba local del multijugador (sin publicar)

Con Node.js instalado: `INICIAR_LOCAL_WINDOWS.bat` (Windows) o
`node server.js` (otras plataformas). Se abre en `http://localhost:3007`.
Esta opción no hace que amigos de otras casas accedan por internet; para ello
publica en Render.

## 🎵 Música por jefe

| Pelea | Archivo |
|---|---|
| Regente de Ceniza | `audio/SPACE_ABYSS.mp3` |
| The Celestial | `audio/IT_DOESNT_END_HERE.mp3` |
| Catalyst | `audio/THIS_WORLD_WILL_COLLAPSE.mp3` |
| Last Man Standing | `audio/THIS_WORLD_WILL_COLLAPSE.mp3` |

Los sprites están en `assets/`. Si falta un archivo, aparecerá un mensaje en
pantalla. Los navegadores exigen un clic para iniciar el sonido.

## Comprobación del servidor

La ruta `/healthz` debe devolver JSON con `ok: true`. La ruta `/assets/` sirve
los sprites y `/audio/` los MP3, incluyendo soporte HTTP Range para la música.

**Nota sobre derechos:** Antes de publicar el juego de forma abierta, asegúrate
de tener permiso para redistribuir las imágenes y las canciones incluidas.
