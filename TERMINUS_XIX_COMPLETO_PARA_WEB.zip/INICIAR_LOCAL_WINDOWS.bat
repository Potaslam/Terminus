@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo TERMINUS XIX - SERVIDOR LOCAL SIN TUNELES
where node >nul 2>&1 || (echo Falta Node.js: https://nodejs.org & pause & exit /b 1)
start "" "http://localhost:3007"
node server.js
pause
