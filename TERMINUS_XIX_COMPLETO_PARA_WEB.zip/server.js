'use strict';
// TERMINUS CO-OP: tiny, dependency-free Node.js HTTP + WebSocket relay.
// Players connect through this server; the host's browser simulates the battle.
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT || 3007);
const HOST = process.env.HOST || '0.0.0.0';
const rooms = new Map();
const peers = new Set();
const html = fs.readFileSync(path.join(__dirname, 'index.html'));
const BUILD = 'TERMINUS XIX WEB PERMANENTE';
const server = http.createServer((req, res) => {
  if (!req.url || !['GET','HEAD'].includes(req.method)) {res.writeHead(405);return res.end()}
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if(pathname==='/healthz'){
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Terminus-Build':BUILD});
    return res.end(req.method==='HEAD'?'':JSON.stringify({ok:true,build:BUILD,maxPlayers:3,rooms:rooms.size}));
  }
  if(pathname==='/tunnel-url'){
    let u='';try{u=fs.readFileSync(path.join(__dirname,'tunnel_url.txt'),'utf8').trim()}catch(e){}
    if(!/^https:\/\/[a-z0-9-]+\.trycloudflare\.com$/.test(u)){res.writeHead(404,{'Content-Type':'application/json'});return res.end('{"error":"Tunnel no disponible"}')}
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});return res.end(JSON.stringify({url:u}));
  }
  if(pathname==='/assets/Celestial_Idle.gif'||pathname==='/assets/CatalystOptim.gif'){const file=path.join(__dirname,'assets',pathname.slice('/assets/'.length));res.writeHead(200,{'Content-Type':'image/gif','Cache-Control':'public, max-age=86400'});return req.method==='HEAD'?res.end():fs.createReadStream(file).pipe(res)}
  const media={'/audio/SPACE_ABYSS.mp3':'SPACE_ABYSS.mp3','/audio/THIS_WORLD_WILL_COLLAPSE.mp3':'THIS_WORLD_WILL_COLLAPSE.mp3','/audio/IT_DOESNT_END_HERE.mp3':'IT_DOESNT_END_HERE.mp3'};
  if(Object.hasOwn(media,pathname)){
    const file=path.join(__dirname,'audio',media[pathname]);const stat=fs.statSync(file);let start=0,end=stat.size-1,status=200;
    const range=req.headers.range;
    if(range){
      const match=/^bytes=(\d*)-(\d*)$/.exec(range);
      if(!match){res.writeHead(416,{'Content-Range':`bytes */${stat.size}`});return res.end()}
      if(match[1]&&match[2]&&Number(match[1])>Number(match[2])){res.writeHead(416);return res.end()}
      if(match[1]){start=Number(match[1]);end=match[2]?Math.min(Number(match[2]),end):end}
      else {const tail=Number(match[2]);start=Math.max(0,stat.size-tail)}
      if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=stat.size){res.writeHead(416,{'Content-Range':`bytes */${stat.size}`});return res.end()}
      status=206;
    }
    const heads={'Content-Type':'audio/mpeg','Accept-Ranges':'bytes','Content-Length':String(end-start+1),'Cache-Control':'public, max-age=86400','X-Content-Type-Options':'nosniff'};
    if(status===206)heads['Content-Range']=`bytes ${start}-${end}/${stat.size}`;
    res.writeHead(status,heads);if(req.method==='HEAD')return res.end();
    return fs.createReadStream(file,{start,end}).pipe(res);
  }
  if (pathname !== '/' && pathname !== '/index.html') {res.writeHead(404);return res.end('No encontrado')}
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Terminus-Build':BUILD,'X-Content-Type-Options':'nosniff'});
  if (req.method==='HEAD')return res.end();
  res.end(html);
});
function send(ws,obj) {if(!ws || ws.closed)return;try{writeFrame(ws.socket,1,Buffer.from(JSON.stringify(obj)))}catch(e){close(ws)}}
function relayRaw(ws,data){if(!ws || ws.closed)return;if(ws.socket.writableLength>48000)return;writeFrame(ws.socket,1,data)}
function writeFrame(socket,op,data=Buffer.alloc(0)) {
  if(socket.destroyed)return;
  const len=data.length;
  let hdr;
  if(len<126){hdr=Buffer.from([0x80|op,len])}
  else if(len<65536){hdr=Buffer.alloc(4);hdr[0]=0x80|op;hdr[1]=126;hdr.writeUInt16BE(len,2)}
  else{hdr=Buffer.alloc(10);hdr[0]=0x80|op;hdr[1]=127;hdr.writeBigUInt64BE(BigInt(len),2)}
  if(socket.writableLength>65000 && op===1)return;
  socket.write(Buffer.concat([hdr,data]));
}
// Slots are permanent for an entire battle, regardless of which browser
// currently simulates it. The authority can migrate if its tab disconnects.
function members(room){return room.members.filter(Boolean)}
function slotOf(room,ws){return room.members.indexOf(ws)}
function connectedPlayers(room){return members(room).length}
function slots(room){return room.members.map(Boolean)}
function broadcast(room,packet,except=null){
 for(const peer of members(room))if(peer!==except)send(peer,packet);
}
function relayGuests(room,raw){
 for(const peer of members(room))if(peer!==room.host)relayRaw(peer,raw);
}
function promoteAfterHostLeaves(room,oldSlot){
 const others=members(room);
 if(!others.length){rooms.delete(room.code);return}
 if(!room.running){
  for(const peer of others){send(peer,{type:'room_closed',reason:'La sala fue cerrada.'});peer.room=null}
  rooms.delete(room.code);return;
 }
 const latest=room.checkpoint;
 const valueOf=peer=>{
  const pl=latest?.players?.[slotOf(room,peer)];
  return (pl?.hp>0?100000:0)+(pl?.lastStand?1000000:0)+(Number(pl?.hp)||0);
 };
 others.sort((a,b)=>valueOf(b)-valueOf(a));
 // During the first few hundred milliseconds there may be no full checkpoint
 // yet. Fall back to the last streamed state, then to a connected participant.
 const candidate=others.find(x=>latest?.players?.[slotOf(room,x)]?.hp>0)||
   (!latest?others.find(x=>room.lastState?.players?.[slotOf(room,x)]?.hp>0)||others[0]:null);
 if(!candidate){
  for(const peer of others){send(peer,{type:'finish',win:false,run:latest?.run||0,stats:[]});}
  room.running=false;room.host=others[0];return;
 }
 room.host=candidate;
 room.paused=false;
 send(candidate,{type:'authority_granted',slot:slotOf(room,candidate),departed:oldSlot,slots:slots(room),checkpoint:latest});
 for(const peer of others)if(peer!==candidate){
  send(peer,{type:'authority_changed',slot:slotOf(room,candidate),departed:oldSlot,slots:slots(room)});
 }
 broadcast(room,{type:'peer',count:connectedPlayers(room),slots:slots(room),left:oldSlot,authority:slotOf(room,candidate)});
}
function close(ws){
 if(ws.closed)return;ws.closed=true;peers.delete(ws);
 const room=ws.room;
 if(room){
  const slot=slotOf(room,ws);
  if(slot>=0){
   room.members[slot]=null;
   if(room.host===ws)promoteAfterHostLeaves(room,slot);
   else{
    if(room.paused){room.paused=false;broadcast(room,{type:'pause_state',paused:false,by:slot})}
    if(room.running)send(room.host,{type:'peer_left',slot});
    broadcast(room,{type:'peer',count:connectedPlayers(room),slots:slots(room),left:slot});
   }
  }
  ws.room=null;
 }
 try{ws.socket.end()}catch(e){}
 setTimeout(()=>{try{ws.socket.destroy()}catch(e){}},250).unref();
}
function handle(ws,msg,raw){
 if(!msg||typeof msg!=='object'||Array.isArray(msg))return;
 if(msg.type==='probe'){if(typeof msg.time==='number')send(ws,{type:'probe_ack',time:msg.time});return}
 if(msg.type==='leave'){close(ws);return}
 if(msg.type==='pause_request'){
  const room=ws.room;if(!room||!room.running)return;
  if(typeof msg.paused!=='boolean'||msg.paused===room.paused)return send(ws,{type:'pause_state',paused:room.paused,by:0});
  const at=Date.now();if(at-room.lastPause<220)return send(ws,{type:'pause_state',paused:room.paused,by:0});
  room.paused=msg.paused;room.lastPause=at;
  const slot=slotOf(room,ws);
  broadcast(room,{type:'pause_state',paused:room.paused,by:slot});return;
 }
 if(msg.type==='create'){
  if(ws.room)return send(ws,{type:'error',message:'Ya estás en una sala.'});
  if(rooms.size>=300)return send(ws,{type:'error',message:'Servidor lleno.'});
  let code;do{code=crypto.randomBytes(5).toString('base64url').replace(/[^A-Z0-9]/gi,'').toUpperCase().slice(0,6)}while(code.length!==6||rooms.has(code));
  const room={code,host:ws,members:[ws,null,null],running:false,paused:false,lastPause:0,checkpoint:null};rooms.set(code,room);ws.room=room;
  send(ws,{type:'room',role:'host',slot:0,code,count:1,slots:slots(room)});
 }
 else if(msg.type==='join'){
  if(ws.room)return send(ws,{type:'error',message:'Ya estás en una sala.'});
  const code=typeof msg.code==='string'?msg.code.toUpperCase().trim():'';
  if(!/^[A-Z0-9]{6}$/.test(code))return send(ws,{type:'error',message:'Código inválido.'});
  const room=rooms.get(code);
  if(!room)return send(ws,{type:'error',message:'Esa sala no existe.'});
  if(room.running)return send(ws,{type:'error',message:'La pelea ya empezó.'});
  const index=room.members.findIndex((peer,i)=>i>0&&!peer);
  if(index===-1)return send(ws,{type:'error',message:'La sala ya tiene 3 jugadores.'});
  room.members[index]=ws;ws.room=room;
  send(ws,{type:'room',role:'guest',slot:index,code,count:connectedPlayers(room),slots:slots(room)});
  broadcast(room,{type:'peer',count:connectedPlayers(room),slots:slots(room),joined:index},ws);
 }
 else if(msg.type==='start'){
  const room=ws.room;if(!room||ws!==room.host||connectedPlayers(room)<2||room.running)return;
  room.running=true;room.paused=false;room.lastPause=0;
  const mode='normal';const bossKind=['regent','celestial','catalyst'].includes(msg.bossKind)?msg.bossKind:'regent';
  for(const [slot,peer] of room.members.entries())if(peer)send(peer,{type:'start',mode,bossKind,slot,players:connectedPlayers(room),slots:slots(room)});
 }
 else if(['state','projectiles','lms'].includes(msg.type)){
  const room=ws.room;if(room&&ws===room.host&&room.running&&!room.paused){if(msg.type==='state')room.lastState=msg;if(msg.type==='projectiles')room.lastProjectiles=msg;relayGuests(room,raw);}
 }
 else if(msg.type==='checkpoint'){
  const room=ws.room;if(room&&room.host===ws&&room.running){
   // Only current authority may write a checkpoint; never rebroadcast it.
   if(Array.isArray(msg.players)&&msg.players.length===3&&msg.boss&&typeof msg.run==='number')room.checkpoint=msg;
  }
 }
 else if(msg.type==='input'){
  const room=ws.room;if(room&&room.running&&!room.paused){
   const index=slotOf(room,ws);
   if(index<0||room.host===ws)return;
   const keys={};for(const name of ['KeyA','KeyD','ArrowLeft','ArrowRight','Space','KeyW','ArrowUp','KeyS','ArrowDown','ShiftLeft','ShiftRight'])if(msg.keys?.[name]===true)keys[name]=true;
   send(room.host,{type:'input',slot:index,keys,mx:Number.isFinite(msg.mx)?Math.max(0,Math.min(2280,msg.mx)):0,my:Number.isFinite(msg.my)?Math.max(0,Math.min(540,msg.my)):0,fire:msg.fire===true,auto:msg.auto===true,predict:msg.predict!==false,assist:Number.isFinite(msg.assist)?Math.max(0,Math.min(100,msg.assist)):35});
  }
 }
 else if(msg.type==='finish'){
  const room=ws.room;if(room&&ws===room.host&&room.running){
   room.running=false;room.paused=false;
   const stats=Array.isArray(msg.stats)?msg.stats.slice(0,3).filter(r=>r&&Number.isInteger(r.slot)&&r.slot>=0&&r.slot<=2).map(r=>({slot:r.slot,damage:Number.isFinite(r.damage)?Math.max(0,Math.min(10000000,r.damage)):0,hits:Number.isFinite(r.hits)?Math.max(0,Math.min(10000,r.hits)):0,aggro:Number.isFinite(r.aggro)?Math.max(0,Math.min(100000,r.aggro)):0})):[];
   broadcast(room,{type:'finish',win:!!msg.win,run:Number.isFinite(msg.run)?msg.run:0,stats},ws);
  }
 }
 else if(msg.type==='ready_again'){
  const room=ws.room;if(room&&ws===room.host){room.running=false;room.paused=false;broadcast(room,{type:'back_lobby',count:connectedPlayers(room)});broadcast(room,{type:'peer',count:connectedPlayers(room),slots:slots(room)})}
 }
}
server.on('upgrade',(req,socket,head)=>{
  const pathname=new URL(req.url||'/', 'http://localhost').pathname;
  if(pathname!=='/ws'||String(req.headers.upgrade||'').toLowerCase()!=='websocket')return socket.destroy();
  const key=req.headers['sec-websocket-key'];
  if(typeof key!=='string'||!Buffer.from(key,'base64').length)return socket.destroy();
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
  const ws={socket,room:null,closed:false,buffer:Buffer.alloc(0),lastSeen:Date.now()};peers.add(ws);
  const receive=bytes=>{
    if(ws.closed)return;ws.lastSeen=Date.now();ws.buffer=Buffer.concat([ws.buffer,bytes]);
    if(ws.buffer.length>900000){close(ws);return}
    while(ws.buffer.length>=2){
      const a=ws.buffer[0],b=ws.buffer[1],opcode=a&15;
      if(!(a&128)){close(ws);return} // browsers send unfragmented small JSON messages
      if(!(b&128)){close(ws);return} // incoming frames MUST be masked
      let len=b&127,pos=2;
      if(len===126){if(ws.buffer.length<4)return;len=ws.buffer.readUInt16BE(2);pos=4}
      if(len===127){if(ws.buffer.length<10)return;const large=ws.buffer.readBigUInt64BE(2);if(large>BigInt(700000)){close(ws);return}len=Number(large);pos=10}
      if(len>700000){close(ws);return}
      if(ws.buffer.length<pos+4+len)return;
      const mask=ws.buffer.subarray(pos,pos+4),data=Buffer.from(ws.buffer.subarray(pos+4,pos+4+len));
      ws.buffer=ws.buffer.subarray(pos+4+len);
      for(let i=0;i<data.length;i++)data[i]^=mask[i%4];
      if(opcode===8){close(ws);return}
      if(opcode===9){writeFrame(socket,10,data);continue}
      if(opcode===10)continue;
      if(opcode!==1){close(ws);return}
      try{handle(ws,JSON.parse(data.toString('utf8')),data)}catch(e){send(ws,{type:'error',message:'Mensaje inválido.'})}
    }
  };
  socket.setNoDelay(true); // send tiny real-time input messages immediately
  socket.on('data',receive);socket.on('error',()=>close(ws));socket.on('close',()=>close(ws));
  if(head.length)receive(head);
});
const pingInterval=setInterval(()=>{
 for(const ws of peers){if(Date.now()-ws.lastSeen>16000){close(ws);continue}try{writeFrame(ws.socket,9)}catch(e){close(ws)}}
},5000);
pingInterval.unref();
server.listen(PORT,HOST,()=>{console.log('╔═══════════════════════════════════════════════════════╗');console.log('║    TERMINUS XIX — WEB PERMANENTE          ║');console.log('╚═══════════════════════════════════════════════════════╝');console.log('  Abre en tu navegador: http://localhost:'+PORT);console.log('  Para otro PC en tu red: http://IP-DE-TU-PC:'+PORT);console.log('  Comparte la dirección y el código de la sala.');console.log('  Ctrl+C para cerrar el servidor.');});
